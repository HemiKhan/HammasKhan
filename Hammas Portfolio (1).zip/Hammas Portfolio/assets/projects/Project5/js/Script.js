
$(".navigation").click(function () {
    $(".navigation").toggleClass("active");
});
